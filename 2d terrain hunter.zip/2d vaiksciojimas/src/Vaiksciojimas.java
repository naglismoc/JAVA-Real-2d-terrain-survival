import java.util.ArrayList;

public class Vaiksciojimas {
    //Terrain terrain = new Terrain(0,0);
    Funkcijos funkcijos = new Funkcijos();

    ArrayList<Padaras> rusis = new ArrayList<>();

    public void rusis() {

        Padaras pirmas = new Padaras(1, 1, true);
        //rusis.add(pirmas);
        rusis.add(new Padaras(0, 0, true));
      //  rusis.add(new Padaras(0, 25, true));
        //rusis.add(new Padaras(25, 0, true));
        //rusis.add(new Padaras(25, 25, true));
    }

    private int kiekEjimu = 50;
    int naujasEjimasX;
    int naujasEjimasY;
    boolean laikinas;
    boolean laikinas2;
    boolean laikinas3;
    int ejimasX;
    int ejimasY;
    Terrain grid = new Terrain(1, 1);
    private int kiekPradzioje;

    //constructor
    public Vaiksciojimas(int gridX, int gridY, int kiekPradzioje) {
        this.kiekEjimu = kiekEjimu;
        this.grid.setGridX(gridX);
        this.grid.setGridY(gridY);
        this.kiekPradzioje = kiekPradzioje;

    }

    //getter
    public int getKiekEjimu() {
        return kiekEjimu;
    }

    //setter
    public void setKiekEjimu(int kiekEjimu) {
        this.kiekEjimu = kiekEjimu;
    }


    //pilnas metodas
    public void pilnasEjimas(int i, boolean laikinas, boolean laikinas2) {

        int j = 0;
        int reset;
        /* CIA SVARBU. WHILE PRIRASIUS "&& rusis.get(j).isArGyvas()" SUSTOJA KAI SUMEDZIOJA*/
        while (j < rusis.size()) {
            reset=0;
           // System.out.println("kiekPrazdioje= " + rusis.size() + " o j = " + j + " ir arGyvas = " + rusis.get(j).isArGyvas());
            System.out.println("eina " + (j + 1) + "-as padaras");

            int Arlaikas = arLaikasNamo();
          //  System.out.println("Arlaikas= " + Arlaikas);
            //  System.out.println("pilnasEjimas tikrina 'laikinas', ar eis x ar y " + i + " " + laikinas + " " + laikinas2);
            if (i < Arlaikas) {
                System.out.println("i - ArLaikas = " + (Arlaikas - i));
                einamXY(i,j,laikinas,laikinas2);
                j++;
            }

            else {
              //  System.out.println("einam namucio");
                laikasNamo2(i, j,reset, laikinas,laikinas2);

                j++;
            }
        }
        // System.out.println(" PADARAS YRA X " + rusis.get(0).getPozicijaX()+" IR Y " + rusis.get(0).getPozicijaY());
    }
    public void einamXY(int i, int j, boolean laikinas, boolean laikinas2){
        if (laikinas) {
            einamX(i, j, laikinas2);
        } else {
            einamY(i, j, laikinas2);
        }
    }

    //ejimas x asimi
    public void einamX(int i, int j, boolean laikinas2) {
        ejimasX = rusis.get(j).getPozicijaX();
        //  System.out.println("einamX atsinesa dvi reiksmes, ejimasX "+ejimasX+" ir laikinas2 -"+laikinas2+". sprendzia eisim i prieki ar atgal. "+laikinas2);
        laikinas2 = funkcijos.rnd();

        if (laikinas2) {
            einamIPriekiX(i, j, ejimasX);
        } else {
            einamAtgalX(i, j, ejimasX);
        }
    }

    // ejimas y asimi
    public void einamY(int i, int j, boolean laikinas2) {
        ejimasY = rusis.get(j).getPozicijaY();
        // System.out.println("einamY atsinesa dvi reiksmes, ejimasY "+ejimasY+" ir laikinas2 -"+laikinas2+". sprendzia eisim i prieki ar atgal. "+laikinas2);
        naujasEjimasY = ejimasY;

        if (laikinas2) {
            einamIPriekiY(i, j, ejimasY);
        } else {
            einamAtgalY(i, j, ejimasY);
        }
    }

    //ejimas x asimi i prieki
    public void einamIPriekiX(int i, int j, int ejimasX) {
        // System.out.println("einame X asimi i prieki");

        if (ejimasX < grid.getGridX()) {
            ejomIPriekiNuejomIPriekiX(i, j);
        } else {
            ejomIPriekiNuejomAtgalX(i, j);
        }

    }

    public void einamAtgalX(int i, int j, int ejimasX) {
        // System.out.println("einame X asimi atgal");
        if (ejimasX > 1) {
            ejomAtgalNuejomAtgalX(i, j);
        } else {
            ejomAtgalNuejomIPRiekiX(i, j);
        }
    }

    public void einamIPriekiY(int i, int j, int ejimasY) {
        //  System.out.println("gridY yra" +grid.getGridY());
        if (ejimasY < grid.getGridY()) {

            ejomIPriekiNuejomIPriekiY(i, j);

        } else {

            ejomIPriekiNuejomAtgalY(i, j);

        }
    }

    public void einamAtgalY(int i, int j, int ejimasY) {
        if (ejimasY > 1) {
            ejomAtgalNuejomAtgalY(i, j);

        } else {
            ejomAtgalNuejomIPRiekiY(i, j);

        }
    }

    public void ejomIPriekiNuejomIPriekiX(int i, int j) {
        naujasEjimasX = ejimasX;
        naujasEjimasX++;
        rusis.get(j).setPozicijaX(naujasEjimasX);
        System.out.println((i + 1) + " ejimu padaras paejo is X " + ejimasX + " i " + naujasEjimasX);
        arMire(j);
    }

    public void ejomIPriekiNuejomAtgalX(int i, int j) {
        naujasEjimasX = ejimasX;
        naujasEjimasX--;
        rusis.get(j).setPozicijaX(naujasEjimasX);
        System.out.println((i + 1) + " ejimu padaras paejo is X " + ejimasX + " i " + naujasEjimasX);
        arMire(j);
    }

    public void ejomAtgalNuejomAtgalX(int i, int j) {
        //  System.out.println("dabartine pozicija X - " + ejimasX + ", minimali galima 1. Galime ir einame i atgal");
        naujasEjimasX = ejimasX;
        naujasEjimasX--;
        rusis.get(j).setPozicijaX(naujasEjimasX);
        System.out.println((i + 1) + " ejimu padaras paejo is X " + ejimasX + " i " + naujasEjimasX);
        arMire(j);
    }

    public void ejomAtgalNuejomIPRiekiX(int i, int j) {
        //  System.out.println("dabartine pozicija X - " +ejimasX+ ", minimali galima 1. kadangi negalime eiti atgal einame i prieki");
        naujasEjimasX = ejimasX;
        naujasEjimasX++;
        rusis.get(j).setPozicijaX(naujasEjimasX);
        System.out.println((i + 1) + " ejimu padaras paejo is X " + ejimasX + " i " + naujasEjimasX);
        arMire(j);
    }

    public void ejomIPriekiNuejomIPriekiY(int i, int j) {
        naujasEjimasY++;
        rusis.get(j).setPozicijaY(naujasEjimasY);
        System.out.println((i + 1) + " ejimu padaras paejo is Y " + ejimasY + " i " + naujasEjimasY);
        arMire(j);
    }

    public void ejomIPriekiNuejomAtgalY(int i, int j) {
        naujasEjimasY--;
        rusis.get(j).setPozicijaY(naujasEjimasY);
        System.out.println((i + 1) + " ejimu padaras paejo is Y " + ejimasY + " i " + naujasEjimasY);
        arMire(j);
    }

    public void ejomAtgalNuejomAtgalY(int i, int j) {
        naujasEjimasY--;
        rusis.get(j).setPozicijaY(naujasEjimasY);
        System.out.println((i + 1) + " ejimu padaras paejo is Y " + ejimasY + " i " + naujasEjimasY);
        arMire(j);
    }

    public void ejomAtgalNuejomIPRiekiY(int i, int j) {
        naujasEjimasY++;
        rusis.get(j).setPozicijaY(naujasEjimasY);
        System.out.println((i + 1) + " ejimu padaras paejo is Y " + ejimasY + " i " + naujasEjimasY);
        arMire(j);
    }


    public void arMire(int j) {
        for (int h = 0; h < rusis.size(); h++) {
            if (j != h) {
                if (naujasEjimasX == rusis.get(h).getPozicijaX()) {
                    if (rusis.get(j).getPozicijaY() == rusis.get(h).getPozicijaY()) {
                        rusis.remove(h);
                        j--;
                        System.out.println("mirooooooooooooooooooooooooooooooooooooooooooo");
//                                    if (!rusis.get(h).isArGyvas()) {
//                                        System.out.println("rado kaulus");
//                                    } else {
//                                        rusis.get(h).setArGyvas(false);
//                                        System.out.println("SUMEDZIOJOOOOOOOOOOOOOOOOOOO");
//                                    }
                    }

                }
            }
        }
    }

    public int arLaikasNamo() {

        //boolean kintamasis;
        int y = grid.getGridY() % 2;//11/2=1
        int y1 = grid.getGridY() / 2;//11/2=5
        if (y != 0) {
            y1 = y1++;
        }//5+1
        int arLaikasNamoY = kiekEjimu - y1;//20-6=14

        //1 2 3 4 5   6   7 8 9 10 11
        int x = grid.getGridX() % 2;
        int x1 = grid.getGridX() / 2;
        if (x != 0) {
            x1 = x1++;
        }
        int arLaikasNamoX = kiekEjimu - x1;//20-6=14
        if (arLaikasNamoX > arLaikasNamoY) {
            int arLaikasNamo = arLaikasNamoY;
            return arLaikasNamo;
        } else {
            int arLaikasNamo = arLaikasNamoX;
            return arLaikasNamo;

        }

    }



    public void laikasNamo2(int i, int j, int reset, boolean laikinas, boolean laikinas2) {
        //System.out.println("inicijuojam laikasNamo2 funkcija");
        int y = grid.getGridY() % 2;
        int y1 = grid.getGridY() / 2;
        if (y == 0) {
            y1 = y1++;
        }
        int x = grid.getGridX() % 2;
        int x1 = grid.getGridX() / 2;
        if (x == 0) {
            x1 = x1++;
        }
        int d = 0;

        int yp1 = grid.getGridY() - rusis.get(j).getPozicijaY();
        int yp2 = rusis.get(j).getPozicijaY();
        int xp1 = grid.getGridX() - rusis.get(j).getPozicijaX();
        int xp2 = rusis.get(j).getPozicijaX();

        if (yp1 <= yp2 && yp1 <= xp1 && yp1 <= xp2) {
            yp1(i,j,reset);
        }
        else if (yp2 <= yp1 && yp2 <= xp1 && yp2 <= xp2) {
            yp2(i,j,reset);

        } else if (xp1 <= yp2 && xp1 <= yp1 && xp1 <= xp2) {
            xp1(i,j,reset);

        } else
            xp2(i,j, reset);
    }
       public void yp1(int i, int j, int reset) {
            if (grid.getGridY() - rusis.get(j).getPozicijaY()  < (kiekEjimu - i)) {
                if (grid.getGridY() - rusis.get(j).getPozicijaY()-(kiekEjimu-i)==1) {
                    einamX(i, j, laikinas2);
                }
                else {
                    einamXY(i, j, laikinas, laikinas2);
                }
            } else {
                if (rusis.get(j).getPozicijaY() < (grid.getGridY() + 1)) {
                    System.out.println("einam y aukstyn");
                    System.out.println((i + 1) + " ejimu padaras paejo is Y " + rusis.get(j).getPozicijaY());
                    rusis.get(j).setPozicijaY((rusis.get(j).getPozicijaY() + 1));
                    System.out.println("i y pozicija " + rusis.get(j).getPozicijaY());
                    reset++;
                } else {
                    System.out.println("padaras namie");
                    reset++;
                }
            }
        }

        public void yp2(int i, int j, int reset){
            if (reset == 0) {
                if (rusis.get(j).getPozicijaY()  < (kiekEjimu - i)) {
                    einamXY(i,j,laikinas,laikinas2);
                } else {
                    if (rusis.get(j).getPozicijaY() > 0) {
                        System.out.println("einam y zemyn");
                        System.out.println((i + 1) + " ejimu padaras paejo is Y " + rusis.get(j).getPozicijaY());
                        rusis.get(j).setPozicijaY((rusis.get(j).getPozicijaY() - 1));
                        System.out.println("i y pozicija " + rusis.get(j).getPozicijaY());
                        reset++;
                    } else {
                        System.out.println("padaras namie");
                        reset++;
                    }
                }
            }
        }

        public void xp1(int i, int j, int reset){
            if (reset == 0) {
                if (grid.getGridX() - rusis.get(j).getPozicijaX() < (kiekEjimu - i)) {//25-22=3, 3< 20-15=5,
                    if (grid.getGridX() - rusis.get(j).getPozicijaX()-(kiekEjimu-i)==1) {
                        einamY(i, j, laikinas2);
                    }
                    else {
                        einamXY(i, j, laikinas, laikinas2);
                    }
                } else {
                    if (rusis.get(j).getPozicijaX() < (grid.getGridX() + 1)) {
                        System.out.println("einam x aukstyn");
                        System.out.println((i + 1) + " ejimu padaras paejo is X " + rusis.get(j).getPozicijaX());
                        rusis.get(j).setPozicijaX((rusis.get(j).getPozicijaX() + 1));
                        System.out.println("i x pozicija " + rusis.get(j).getPozicijaX());
                        reset++;
                    } else {
                        System.out.println("padaras namie");
                        reset++;
                    }
                }
            }
        }

        public void xp2(int i, int j, int reset){
            if (rusis.get(j).getPozicijaX() > 0 && rusis.get(j).getPozicijaX() < (grid.getGridX() + 1)) {
                if (reset == 0) {
                    if (rusis.get(j).getPozicijaX() + 1 < (kiekEjimu - i)) {
                        einamXY(i,j,laikinas,laikinas2);
                    } else {
                        if (rusis.get(j).getPozicijaX() > 0) {
                            System.out.println("einam x zemyn");
                            System.out.println((i + 1) + " ejimu padaras paejo is X " + rusis.get(j).getPozicijaX());
                            rusis.get(j).setPozicijaX((rusis.get(j).getPozicijaX() - 1));
                            System.out.println("i x pozicija " + rusis.get(j).getPozicijaX());
                            reset++;
                        } else {
                            System.out.println("padaras namie");
                            reset++;
                        }
                    }
                }
            }
        }





}








