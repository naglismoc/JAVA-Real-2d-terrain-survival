public class Padaras {
    private int pozicijaX;
    private int pozicijaY;
    private boolean arGyvas=true;
    private int KiekPradzioje;
    public Padaras(int pozicijaX, int pozicijaY, boolean arGyvas) {
        this.pozicijaX = pozicijaX;
        this.pozicijaY = pozicijaY;
        this.arGyvas = arGyvas;
    }

    public Padaras() {
    }
    public Padaras(int kiekPradzioje) {
    }
    public int getPozicijaX() {
        return pozicijaX;
    }

    public boolean isArGyvas() {
        return arGyvas;
    }

    public void setArGyvas(boolean arGyvas) {
        this.arGyvas = arGyvas;
    }

    public void setPozicijaX(int pozicijaX) {
        this.pozicijaX = pozicijaX;
    }

    public int getPozicijaY() {
        return pozicijaY;
    }

    public void setPozicijaY(int pozicijaY) {
        this.pozicijaY = pozicijaY;
    }

}
