import java.util.*;
public class Funkcijos {


    public Funkcijos() {
    }

    public boolean rnd(){
        double Mrnd =Math.random();
        if (Mrnd>=0.5){
            return true;
        }
        else{
            return false;
        }
    }
//    public boolean arMire(int j){
//        if ( Vaiksciojimas.rusis.get(j).getPozicijaX()){
//            return true;
//        }
//        else{
//            return false;
//        }
//    }
}
