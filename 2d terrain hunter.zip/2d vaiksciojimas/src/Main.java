import java.util.*;
public class Main {

    public static void main(String[] args) {

        //Terrain terrain = new Terrain(0,0);

        Funkcijos funkcijos= new Funkcijos();

        int gridX=25;
        int gridY=25;
        int kiekEjimu=20;
        int KiekPradzioje=1;
        boolean laikinas;
        boolean laikinas2;
        Vaiksciojimas vaiksciojimas = new Vaiksciojimas(gridX,gridY,KiekPradzioje);
        Padaras padaras = new Padaras();
        vaiksciojimas.setKiekEjimu(kiekEjimu);


        vaiksciojimas.rusis();
        int i=0;
        while( i<kiekEjimu && gridX!=0 && gridY!=0) {
            i++;

            laikinas = funkcijos.rnd();
            laikinas2 = funkcijos.rnd();

            vaiksciojimas.pilnasEjimas(i, laikinas, laikinas2);

        }
    }
}
